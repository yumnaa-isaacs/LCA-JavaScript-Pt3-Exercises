function validateLogin() {
  let username = document.getElementById("username").value;
  let password = document.getElementById("password").value;

  if (username === "admin" && password === "password123") {
    window.location.href = "index.html";
  } else {
    console.log("Invalid credentials");
    document.getElementById("errorModal").style.display = "flex";
  }
}

function dismissModal() {
  document.getElementById("errorModal").style.display = "none";
}

function toggleNav() {
  let sidebar = document.getElementById("sidebar");
  let mainContent = document.querySelector(".main-content");
  let topbar = document.querySelector(".topbar");

  if (sidebar.style.width === "250px") {
    sidebar.style.width = "0";
    mainContent.style.marginLeft = "0";
    topbar.style.marginLeft = "0";
  } else {
    sidebar.style.width = "250px";
    mainContent.style.marginLeft = "250px";
    topbar.style.marginLeft = "250px";
  }
}