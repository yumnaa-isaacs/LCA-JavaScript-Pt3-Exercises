let developers = [];
let filteredDevelopers = [];
let isCardView = true;

const developersContainer = document.getElementById("developersContainer");
const developerCount = document.getElementById("developerCount");
const searchInput = document.getElementById("searchInput");
const toggleViewBtn = document.getElementById("toggleViewBtn");
const developerForm = document.getElementById("developerForm");

const nameInput = document.getElementById("name");
const roleInput = document.getElementById("role");
const skillInput = document.getElementById("skill");

const nameError = document.getElementById("nameError");
const roleError = document.getElementById("roleError");
const skillError = document.getElementById("skillError");

// Load developers from JSON
fetch("developers.json")
  .then(response => response.json())
  .then(data => {
    developers = data.map(dev => ({
      ...dev,
      availableForHire: false
    }));

    filteredDevelopers = [...developers];
    renderDevelopers(filteredDevelopers);
  })
  .catch(error => {
    developersContainer.innerHTML = `
      <div class="col-12">
        <div class="alert alert-danger">
          Failed to load developers.json
        </div>
      </div>
    `;
    console.error("Error loading JSON:", error);
  });

// Render developers in card or table view
function renderDevelopers(data) {
  developerCount.textContent = data.length;

  if (data.length === 0) {
    developersContainer.innerHTML = `
      <div class="col-12">
        <div class="empty-state">
          <h3>No developers found</h3>
          <p class="mb-0">Try a different search term or add a new developer.</p>
        </div>
      </div>
    `;
    return;
  }

  if (isCardView) {
    renderCardView(data);
  } else {
    renderTableView(data);
  }
}

// Card view
function renderCardView(data) {
  developersContainer.className = "row g-4";
  developersContainer.innerHTML = "";

  data.forEach((dev, index) => {
    const card = document.createElement("div");
    card.className = "col-md-6 col-lg-4";

    card.innerHTML = `
      <div class="card dev-card shadow-sm border-0">
        <div class="card-body">
          <h3 class="h5 mb-2">${dev.name}</h3>
          <p class="mb-2"><strong>Role:</strong> ${dev.role}</p>
          <p class="mb-3">
            <strong>Skill:</strong>
            <span class="dev-skill">${dev.skill}</span>
          </p>

          <button class="btn btn-outline-success btn-sm hire-toggle-btn" data-index="${index}">
            ${dev.availableForHire ? "Remove Hire Badge" : "Mark Available for Hire"}
          </button>

          <div class="mt-3">
            <span class="badge bg-success hire-badge ${dev.availableForHire ? "" : "d-none"}">
              Available for Hire
            </span>
          </div>
        </div>
      </div>
    `;

    developersContainer.appendChild(card);
  });

  attachHireButtonEvents(data);
}

// Table view
function renderTableView(data) {
  developersContainer.className = "";
  developersContainer.innerHTML = `
    <div class="table-wrapper">
      <table class="table table-hover align-middle mb-0">
        <thead>
          <tr>
            <th>Name</th>
            <th>Role</th>
            <th>Skill</th>
            <th>Hire Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="developerTableBody"></tbody>
      </table>
    </div>
  `;

  const tableBody = document.getElementById("developerTableBody");

  data.forEach((dev, index) => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${dev.name}</td>
      <td>${dev.role}</td>
      <td><span class="dev-skill">${dev.skill}</span></td>
      <td>
        <span class="badge bg-success hire-badge ${dev.availableForHire ? "" : "d-none"}">
          Available for Hire
        </span>
      </td>
      <td>
        <button class="btn btn-outline-success btn-sm hire-toggle-btn" data-index="${index}">
          ${dev.availableForHire ? "Remove Badge" : "Toggle Badge"}
        </button>
      </td>
    `;

    tableBody.appendChild(row);
  });

  attachHireButtonEvents(data);
}

// Attach badge toggle buttons
function attachHireButtonEvents(currentList) {
  const hireButtons = document.querySelectorAll(".hire-toggle-btn");

  hireButtons.forEach(button => {
    button.addEventListener("click", function () {
      const index = this.dataset.index;
      currentList[index].availableForHire = !currentList[index].availableForHire;
      renderDevelopers(filteredDevelopers);
    });
  });
}

// Search filter
searchInput.addEventListener("input", function () {
  const searchTerm = this.value.toLowerCase().trim();

  filteredDevelopers = developers.filter(dev =>
    dev.name.toLowerCase().includes(searchTerm) ||
    dev.role.toLowerCase().includes(searchTerm) ||
    dev.skill.toLowerCase().includes(searchTerm)
  );

  renderDevelopers(filteredDevelopers);
});

// Toggle between card and table view
toggleViewBtn.addEventListener("click", function () {
  isCardView = !isCardView;

  toggleViewBtn.textContent = isCardView
    ? "Switch to Table View"
    : "Switch to Card View";

  renderDevelopers(filteredDevelopers);
});

// Validate form
function validateForm() {
  let isValid = true;

  nameError.textContent = "";
  roleError.textContent = "";
  skillError.textContent = "";

  if (nameInput.value.trim() === "") {
    nameError.textContent = "Developer name is required.";
    isValid = false;
  }

  if (roleInput.value.trim() === "") {
    roleError.textContent = "Role is required.";
    isValid = false;
  }

  if (skillInput.value.trim() === "") {
    skillError.textContent = "Skill is required.";
    isValid = false;
  }

  return isValid;
}

// Add developer form submit
developerForm.addEventListener("submit", function (event) {
  event.preventDefault();

  if (!validateForm()) {
    return;
  }

  const newDeveloper = {
    name: nameInput.value.trim(),
    role: roleInput.value.trim(),
    skill: skillInput.value.trim(),
    availableForHire: false
  };

  developers.push(newDeveloper);

  const searchTerm = searchInput.value.toLowerCase().trim();

  filteredDevelopers = developers.filter(dev =>
    dev.name.toLowerCase().includes(searchTerm) ||
    dev.role.toLowerCase().includes(searchTerm) ||
    dev.skill.toLowerCase().includes(searchTerm)
  );

  renderDevelopers(filteredDevelopers);
  developerForm.reset();
});